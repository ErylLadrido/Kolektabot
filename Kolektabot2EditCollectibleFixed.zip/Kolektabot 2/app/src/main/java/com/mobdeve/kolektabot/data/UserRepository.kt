package com.mobdeve.kolektabot.data

import android.util.Log
import com.mobdeve.kolektabot.models.ChangePassword
import com.mobdeve.kolektabot.models.User
import com.mobdeve.kolektabot.models.UserDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class UserRepository @Inject constructor(private val userDao: UserDao) {

    suspend fun registerUser(fullName: String, email: String, password: String, confirmPassword: String): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                val existingUser = userDao.getUserByEmail(email)
                if (existingUser != null) {
                    return@withContext Result.failure(Exception("User with this email already exists"))
                }
                if(password != confirmPassword){
                    return@withContext  Result.failure(Exception("Passwords do not match"))
                }

                val user = User(
                    fullName = fullName,
                    email = email,
                    password = password
                )

                val userId = userDao.insertUser(user)
                val createdUser = user.copy(id = userId.toInt())
                Result.success(createdUser)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun loginUser(email: String, password: String): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                val user = userDao.getUserByEmail(email)
                if (user != null && user.password == password) {
                    Result.success(user)
                } else {
                    Result.failure(Exception("Invalid email or password"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun getUserById(userId: Int): User? {
        return withContext(Dispatchers.IO) {
            userDao.getUserById(userId)
        }
    }

    suspend fun changePassword(
        email: String,
        currentPassword: String,
        change: ChangePassword
    ): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                Log.d("ChangePassword", "Input email: $email")
                Log.d("ChangePassword", "Input current password: $currentPassword")
                val user = userDao.getUserByEmail(email)
                if (user != null && user.password == currentPassword) {
                    if (change.newPassword == change.confirmPassword) {
                        userDao.updatePassword(email, change.newPassword)
                        // Return the updated user (optional: update password in object)
                        Result.success(user.copy(password = change.newPassword))
                    } else {
                        Result.failure(Exception("New password and confirm password do not match"))
                    }
                } else {
                    Result.failure(Exception("Incorrect current password"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }


}