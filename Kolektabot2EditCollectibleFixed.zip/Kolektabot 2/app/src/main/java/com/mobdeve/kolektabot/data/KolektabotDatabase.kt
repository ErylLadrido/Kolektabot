package com.mobdeve.kolektabot.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.mobdeve.kolektabot.models.Collectible
import com.mobdeve.kolektabot.models.CollectibleDao
import com.mobdeve.kolektabot.models.User
import com.mobdeve.kolektabot.models.UserDao

@Database(
    entities = [User::class, Collectible::class],
    version = 4, // 1. INCREMENT the database version to 3
    exportSchema = false
)
abstract class KolektabotDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun collectibleDao(): CollectibleDao

    companion object {
        // 2. DEFINE THE MIGRATION
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Room can't automatically handle the old imageRes column.
                // We will add the new imageUri column and the old one will be ignored.
                database.execSQL("ALTER TABLE collectibles ADD COLUMN imageUri TEXT")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Add the new isWishlistItem column, defaulting to 0 (false)
                database.execSQL("ALTER TABLE collectibles ADD COLUMN isWishlistItem INTEGER NOT NULL DEFAULT 0")
            }
        }


        @Volatile
        private var INSTANCE: KolektabotDatabase? = null

        fun getDatabase(context: Context): KolektabotDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KolektabotDatabase::class.java,
                    "kolektabot_database"
                )
                    .addMigrations(MIGRATION_2_3) // 3. ADD the migration to the builder
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}