// RepositoryModule.kt
package com.mobdeve.kolektabot.di

import com.mobdeve.kolektabot.data.UserRepository
import com.mobdeve.kolektabot.models.UserDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideUserRepository(userDao: UserDao): UserRepository {
        return UserRepository(userDao)
    }
}