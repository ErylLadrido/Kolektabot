package com.mobdeve.kolektabot.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mobdeve.kolektabot.data.UserPreferences
import com.mobdeve.kolektabot.data.UserRepository
import com.mobdeve.kolektabot.models.User
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val userPreferences: UserPreferences
) : ViewModel() {

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun loginUser(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _errorMessage.value = null
            val result = userRepository.loginUser(email, password)
            if (result.isSuccess) {
                val user = result.getOrNull()!!
                userPreferences.saveCurrentUser(user.id, user.email, user.fullName)
                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "Login failed"
            }
        }
    }

    fun registerUser(fullName: String, email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _errorMessage.value = null
            val result = userRepository.registerUser(fullName, email, password)
            if (result.isSuccess) {
                val user = result.getOrNull()!!
                userPreferences.saveCurrentUser(user.id, user.email, user.fullName)
                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "Registration failed"
            }
        }
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }
}