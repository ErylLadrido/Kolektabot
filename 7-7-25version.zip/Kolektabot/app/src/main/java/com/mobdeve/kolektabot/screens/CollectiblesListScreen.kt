package com.mobdeve.kolektabot.screens

// Make sure you have these imports
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import com.mobdeve.kolektabot.models.CollectibleViewModel
// Other necessary imports
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mobdeve.kolektabot.models.Collectible
import com.mobdeve.kolektabot.viewmodels.AuthViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectiblesListScreen(
    // 1. REMOVE the 'collectibles' parameter from here
    onCollectibleClick: (Collectible) -> Unit,
    onNavigateBack: () -> Unit,
    onAddCollectible: () -> Unit,
    // 2. ADD the ViewModel parameter
    collectibleViewModel: CollectibleViewModel = hiltViewModel(),
    authViewModel: AuthViewModel,
) {
    // 3. GET the list of collectibles from the ViewModel
    val email by authViewModel.currentEmail.collectAsState()
    LaunchedEffect(email) {
        collectibleViewModel.setUserEmail(email.toString())
    }
    val collectibles by collectibleViewModel.allCollectibles.collectAsState()
    var searchQuery by remember { mutableStateOf("") }


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Collection") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Handle search */ }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddCollectible,
                icon = { Icon(Icons.Default.Add, contentDescription = "Add") },
                text = { Text("Add Item") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search collection...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )

            // Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = true,
                    onClick = { /* Toggle filter */ },
                    label = { Text("All") }
                )
                FilterChip(
                    selected = false,
                    onClick = { /* Toggle filter */ },
                    label = { Text("Comics") }
                )
                FilterChip(
                    selected = false,
                    onClick = { /* Toggle filter */ },
                    label = { Text("Toys") }
                )
            }

            // Collectibles List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // This part is now correct and will use the 'collectibles' from the ViewModel
                items(collectibles) { collectible ->
                    // Make sure you have a Composable named CollectibleItem
                    // If not, you'll need to create one or replace this with a Text composable for testing
                    CollectibleItem(
                        collectible = collectible,
                        onClick = { onCollectibleClick(collectible) }
                    )
                }
            }
        }
    }
}