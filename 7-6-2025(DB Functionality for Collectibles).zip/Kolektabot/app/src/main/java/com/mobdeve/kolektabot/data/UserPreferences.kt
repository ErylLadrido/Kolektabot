package com.mobdeve.kolektabot.data

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import javax.inject.Inject

class UserPreferences @Inject constructor(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("kolektabot_prefs", Context.MODE_PRIVATE)

    fun saveCurrentUser(userId: Int, email: String, fullName: String) {
        sharedPreferences.edit().apply {
            putInt("current_user_id", userId)
            putString("current_user_email", email)
            putString("current_user_full_name", fullName)
            putBoolean("is_logged_in", true)
            apply()
        }
    }

    fun getCurrentUserId(): Int {
        return sharedPreferences.getInt("current_user_id", -1)
    }

    fun getCurrentUserEmail(): String {
        return sharedPreferences.getString("current_user_email", "") ?: ""
    }

    fun getCurrentUserFullName(): String {
        return sharedPreferences.getString("current_user_full_name", "") ?: ""
    }

    fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean("is_logged_in", false)
    }

    fun logout() {
        sharedPreferences.edit { clear() }
    }
}