package com.mobdeve.kolektabot.models

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mobdeve.kolektabot.data.CollectibleRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class CollectibleDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    collectibleRepository: CollectibleRepository
) : ViewModel() {

    // Get the collectibleId from the navigation arguments
    private val collectibleId: Int = checkNotNull(savedStateHandle["collectibleId"])

    // Fetch the collectible and expose it as a StateFlow
    val collectible: StateFlow<Collectible> =
        collectibleRepository.getCollectibleById(collectibleId)
            .filterNotNull() // Ensure we don't proceed with a null collectible
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                // You can provide a default/initial collectible state here if needed
                initialValue = Collectible(id = 0, name = "Loading...", category = "", dateAdded = "", purchasePrice = 0.0, purchaseLocation = "", worthThePrice = false, notes = "", imageUri = null)
            )
}