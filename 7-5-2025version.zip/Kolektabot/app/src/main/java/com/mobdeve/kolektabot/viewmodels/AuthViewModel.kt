package com.mobdeve.kolektabot.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mobdeve.kolektabot.data.UserPreferences
import com.mobdeve.kolektabot.data.UserRepository
import com.mobdeve.kolektabot.models.ChangePassword
import com.mobdeve.kolektabot.models.User
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
open class AuthViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val userPreferences: UserPreferences
) : ViewModel() {

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _currentEmail = MutableStateFlow<String?>(null)
    val currentEmail: StateFlow<String?> = _currentEmail


    fun loginUser(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _errorMessage.value = null
            val result = userRepository.loginUser(email, password)
            if (result.isSuccess) {
                val user = result.getOrNull()!!
                userPreferences.saveCurrentUser(user.id, user.email, user.fullName)

                _currentEmail.value = user.email

                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "Login failed"
            }
        }
    }

    fun registerUser(fullName: String, email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _errorMessage.value = null
            val result = userRepository.registerUser(fullName, email, password)
            if (result.isSuccess) {
                val user = result.getOrNull()!!
                userPreferences.saveCurrentUser(user.id, user.email, user.fullName)
                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "Registration failed"
            }
        }
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun changePassword(
        email: String,
        change: ChangePassword,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = userRepository.changePassword(email, change.currentPassword, change)
            if (result.isSuccess) {
                onSuccess()
            } else {
                val error = result.exceptionOrNull()?.message ?: "Password change failed"
                onError(error)
            }
        }
    }

}