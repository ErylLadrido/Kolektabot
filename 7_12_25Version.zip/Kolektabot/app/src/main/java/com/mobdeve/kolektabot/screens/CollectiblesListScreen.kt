package com.mobdeve.kolektabot.screens

// Make sure you have these imports
import androidx.compose.foundation.horizontalScroll
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import com.mobdeve.kolektabot.models.CollectibleViewModel
// Other necessary imports
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mobdeve.kolektabot.models.Collectible
import com.mobdeve.kolektabot.viewmodels.AuthViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectiblesListScreen(
    // 1. REMOVE the 'collectibles' parameter from here
    onCollectibleClick: (Collectible) -> Unit,
    onNavigateBack: () -> Unit,
    onAddCollectible: () -> Unit,
    // 2. ADD the ViewModel parameter
    collectibleViewModel: CollectibleViewModel = hiltViewModel(),
    authViewModel: AuthViewModel,
) {
    // 3. GET the list of collectibles from the ViewModel
    val email by authViewModel.currentEmail.collectAsState()
    LaunchedEffect(email) {
        collectibleViewModel.setUserEmail(email.toString())
    }
    val collectibles by collectibleViewModel.allCollectibles.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val categories = listOf("All", "Comics", "Toys", "Trading Cards", "Figurines", "Books", "Other")
    var selectedCategory by remember { mutableStateOf("All") }

    val filteredCollectibles = collectibles.filter { collectible ->
        val matchesCategory = selectedCategory == "All" || collectible.category.equals(selectedCategory, ignoreCase = true)
        val matchesSearch = collectible.name.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Collection") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Handle search */ }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddCollectible,
                icon = { Icon(Icons.Default.Add, contentDescription = "Add") },
                text = { Text("Add Item") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search collection...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )

            // Filter Chips
            val scrollState = rememberScrollState()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        label = { Text(category) }
                    )
                }
            }


            // Collectibles List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredCollectibles) { collectible ->
                    CollectibleItem(
                        collectible = collectible,
                        onClick = { onCollectibleClick(collectible) }
                    )
                }
            }
        }
    }


}