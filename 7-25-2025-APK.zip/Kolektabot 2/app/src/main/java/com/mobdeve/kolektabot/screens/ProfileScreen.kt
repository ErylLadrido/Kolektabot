package com.mobdeve.kolektabot.screens


import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.mobdeve.kolektabot.R
import com.mobdeve.kolektabot.data.UserPreferences
import com.mobdeve.kolektabot.data.UserRepository
import com.mobdeve.kolektabot.models.ChangePassword
import com.mobdeve.kolektabot.ui.theme.KolektabotTheme
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import com.mobdeve.kolektabot.viewmodels.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    authViewModel: AuthViewModel,
    onNavigateToCollection: () -> Unit,
    onNavigateToWishlist: () -> Unit,
    onNavigateToHome: () -> Unit,
    onLogout: () -> Unit
) {

    // State to show/hide dialog
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    rememberCoroutineScope()

    val context = LocalContext.current
    val userPreferences = UserPreferences(context)
    val email = userPreferences.getCurrentUserEmail()

    LaunchedEffect(email) {
        if (!email.isNullOrBlank()) {
            authViewModel.setEmail(email)
            authViewModel.loadUserAchievements(email)
        }
    }

    val first by authViewModel.firstUploadAchieved.collectAsState()
    val location by authViewModel.locationAchieved.collectAsState()
    val complete by authViewModel.completeAchieved.collectAsState()

    Log.d("PROFILE", email)
    Log.d("PROFILEFIRST", first.toString())
    Log.d("PROFILELOC", location.toString())
    Log.d("PROFILECOMP", complete.toString())

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Kolektabot",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold
                        )
                    )
                },
                actions = {
                    IconButton(onClick = { /* TODO: Handle search action */ }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                    IconButton(onClick = { /* TODO: Handle profile action */ }) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Profile")
                    }
                }
            )
        },

        bottomBar = {
            Column {

                // Bottom navigation bar
                NavigationBar {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home") },
                        selected = false,
                        onClick = onNavigateToHome
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Collections, contentDescription = "Collection") },
                        label = { Text("Collection") },
                        selected = false,
                        onClick = onNavigateToCollection
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Favorite, contentDescription = "Wishlist") },
                        label = { Text("Wishlist") },
                        selected = false,
                        onClick = onNavigateToWishlist
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Popup change password

            if (showChangePasswordDialog) {
                var currentPassword by remember { mutableStateOf("") }
                var newPassword by remember { mutableStateOf("") }
                var confirmPassword by remember { mutableStateOf("") }
                var passwordVisible by remember { mutableStateOf(false) }
                var errorMessage by remember { mutableStateOf<String?>(null) }

                AlertDialog(
                    onDismissRequest = { showChangePasswordDialog = false },
                    title = { Text("Change Password") },
                    text = {
                        Column {
                            OutlinedTextField(
                                value = currentPassword,
                                onValueChange = { currentPassword = it },
                                label = { Text("Current Password") },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            imageVector = if (passwordVisible) Icons.Default.Visibility
                                            else Icons.Default.VisibilityOff,
                                            contentDescription = null
                                        )
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = newPassword,
                                onValueChange = { newPassword = it },
                                label = { Text("New Password") },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = confirmPassword,
                                onValueChange = { confirmPassword = it },
                                label = { Text("Confirm Password") },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )

                            if (errorMessage != null) {
                                Text(
                                    text = errorMessage!!,
                                    color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            val change = ChangePassword(
                                currentPassword = currentPassword,
                                newPassword = newPassword,
                                confirmPassword = confirmPassword
                            )

                            // Call ViewModel’s changePassword function with callbacks
                            authViewModel.changePassword(
                                email = email.toString(),
                                change = change,
                                onSuccess = {
                                    showChangePasswordDialog = false
                                    errorMessage = null
                                    // Optionally show a success toast/snackbar here
                                },
                                onError = { message ->
                                    errorMessage = message
                                }
                            )
                        }) {
                            Text("Confirm")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            showChangePasswordDialog = false
                            errorMessage = null
                        }) {
                            Text("Cancel")
                        }
                    }
                )
            }

            Text(
                text = "Your Achievements",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.padding(bottom = 16.dp)
            )


            val imageList = listOf(
                if (first) R.drawable.first_upload_achievement_acq else R.drawable.first_upload_achievement_unq,
                if (location) R.drawable.location_achievement_acq else R.drawable.location_achievement_unq,
                if (complete) R.drawable.complete_achievement_acq else R.drawable.complete_achievement_unq
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                imageList.forEach { imageRes ->
                    Image(
                        painter = painterResource(id = imageRes),
                        contentDescription = null,
                        modifier = Modifier
                            .size(64.dp)
                    )
                }
            }

            Button(
                onClick = { showChangePasswordDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Text(
                    text = "Change Password",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                    color = Color.White
                )
            }



            // Logout button at the bottom
            Button(
                onClick = {
                    userPreferences.logout()
                    onLogout()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ExitToApp,
                    contentDescription = "Logout",
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = "Logout",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
    }
}




/*
This causes errors due to the authViewModel parameter that I cant seem to solve
But its just for preview so i guess its fine
@Preview(showBackground = true)
@Composable
fun ProfileScreenPreview() {
    KolektabotTheme {
        val fakeViewModel = remember { FakeAuthViewModel() }
        ProfileScreen(
            authViewModel = fakeViewModel,
            onNavigateToCollection = {},
            onNavigateToWishlist = {},
            onNavigateToHome = {},
            onLogout = {}
        )
    }
}
*/