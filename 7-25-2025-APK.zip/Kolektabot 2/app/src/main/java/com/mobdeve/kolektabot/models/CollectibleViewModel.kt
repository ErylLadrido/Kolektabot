package com.mobdeve.kolektabot.models

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

// HiltViewModel enables injection
@HiltViewModel
class CollectibleViewModel @Inject constructor(
    private val collectibleDao: CollectibleDao
) : ViewModel() {

    // Use stateIn to convert the Flow from Room into a StateFlow that the UI can collect
    private val _userEmail = MutableStateFlow<String?>(null)
    val userEmail: StateFlow<String?> = _userEmail

    fun setUserEmail(email: String) {
        _userEmail.value = email
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val allCollectibles: StateFlow<List<Collectible>> =
        userEmail
            .filterNotNull()
            .flatMapLatest { email ->
                collectibleDao.getAllCollectibles(email)
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

    fun addOrUpdateCollectible(collectible: Collectible) {
        viewModelScope.launch {
            collectibleDao.insertOrUpdateCollectible(collectible)
        }
    }


    @OptIn(ExperimentalCoroutinesApi::class)
    val recentCollectibles: StateFlow<List<Collectible>> =
        userEmail
            .filterNotNull()
            .flatMapLatest { email ->
                collectibleDao.getRecentlyAdded(email)
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

    val wishlistItems: StateFlow<List<Collectible>> =
        collectibleDao.getWishlistItems()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = emptyList()
            )

    fun deleteCollectible(collectible: Collectible) {
        viewModelScope.launch {
            collectibleDao.deleteCollectible(collectible)
        }
    }
}