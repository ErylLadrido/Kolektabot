package com.mobdeve.kolektabot.models

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CollectibleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateCollectible(collectible: Collectible)

    @Query("SELECT * FROM collectibles WHERE email LIKE :email ORDER BY name ASC")
    fun getAllCollectibles(email: String): Flow<List<Collectible>>

    @Query("SELECT * FROM collectibles WHERE id = :collectibleId")
    fun getCollectibleById(collectibleId: Int): Flow<Collectible>

    @Query("SELECT * FROM collectibles WHERE isWishlistItem = 1 ORDER BY name ASC")
    fun getWishlistItems(): Flow<List<Collectible>>

    @Delete
    suspend fun deleteCollectible(collectible: Collectible)

    @Query("SELECT * FROM collectibles WHERE email = :email ORDER BY id DESC LIMIT 3")
    fun getRecentlyAdded(email: String): Flow<List<Collectible>>

}