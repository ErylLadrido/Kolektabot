package com.mobdeve.kolektabot.models

data class ChangePassword(
    val currentPassword: String,
    val newPassword: String,
    val confirmPassword: String
)