package com.mobdeve.kolektabot.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mobdeve.kolektabot.data.UserPreferences
import com.mobdeve.kolektabot.screens.*
import com.mobdeve.kolektabot.viewmodels.AuthViewModel

@Composable
fun AppNavigation(
    userPreferences: UserPreferences = UserPreferences(LocalContext.current)
) {
    val navController = rememberNavController()
    val startDestination = if (userPreferences.isLoggedIn()) "home" else "splash"
    // The authViewModel is created here
    val authViewModel: AuthViewModel = hiltViewModel()


    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable("splash") {
            SplashScreen(
                onNavigateToLogin = {
                    navController.navigate("login") {
                        popUpTo("splash") { inclusive = true }
                    }
                }
            )
        }
        composable("login") {
            LoginScreen(
                authViewModel = authViewModel,
                onLoginSuccess = {
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate("register")
                }
            )
        }
        composable("register") {
            RegisterScreen(
                onRegisterSuccess = {
                    navController.navigate("home") {
                        popUpTo("register") { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    navController.navigate("login") {
                        popUpTo("register") { inclusive = true }
                    }
                }
            )
        }
        composable("home") {
            HomeScreen(
                onNavigateToCollection = { navController.navigate("collection") },
                onNavigateToAddItem = { navController.navigate("addCollectible") },
                onNavigateToProfile = { navController.navigate("profile") },
                onNavigateToDetail = { collectibleId ->
                    navController.navigate("detail/$collectibleId")
                }
            )
        }
        composable("collection") {
            CollectiblesListScreen(
                onCollectibleClick = { collectible ->
                    navController.navigate("detail/${collectible.id}")
                },
                onNavigateBack = { navController.popBackStack() },
                onAddCollectible = { navController.navigate("addCollectible") }
            )
        }
        composable(
            route = "detail/{collectibleId}",
            arguments = listOf(navArgument("collectibleId") { type = NavType.IntType })
        ) { backStackEntry ->
            val collectibleId = backStackEntry.arguments?.getInt("collectibleId") ?: 0
            CollectibleDetailScreen(
                onEditCollectible = {
                    navController.navigate("edit/${collectibleId}")
                },
                onNavigateBack = { navController.popBackStack() },
                onNavigateToCollection = { navController.navigate("collection")},
                onNavigateToHome = { navController.navigate("home")}
            )
        }
        composable("addCollectible") {
            AddEditCollectibleScreen(
                onSave = {
                    navController.popBackStack()
                },
                onCancel = { navController.popBackStack() },
                // ADD THIS LINE
                authViewModel = authViewModel
            )
        }
        composable(
            route = "edit/{collectibleId}",
            arguments = listOf(navArgument("collectibleId") { type = NavType.IntType })
        ) {
            AddEditCollectibleScreen(
                onSave = {
                    navController.popBackStack()
                },
                onCancel = { navController.popBackStack() },
                // ADD THIS LINE HERE AS WELL
                authViewModel = authViewModel
            )
        }

        composable("profile") {
            ProfileScreen(
                authViewModel = authViewModel,
                onNavigateToCollection = { navController.navigate("collection") },
                onNavigateToWishlist = { navController.navigate("wishlist") },
                onNavigateToHome = { navController.navigate("home") },
                onLogout = {
                    navController.navigate("login") {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
    }
}