package com.mobdeve.kolektabot.viewmodels

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mobdeve.kolektabot.data.UserPreferences
import com.mobdeve.kolektabot.data.UserRepository
import com.mobdeve.kolektabot.models.ChangePassword
import com.mobdeve.kolektabot.models.User
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
open class AuthViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val userPreferences: UserPreferences
) : ViewModel() {

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var _currentEmail = MutableStateFlow<String?>(null)
    var currentEmail: StateFlow<String?> = _currentEmail

    private val _firstUploadAchieved = MutableStateFlow(false)
    val firstUploadAchieved: StateFlow<Boolean> = _firstUploadAchieved

    private val _locationAchieved = MutableStateFlow(false)
    val locationAchieved: StateFlow<Boolean> = _locationAchieved

    private val _completeAchieved = MutableStateFlow(false)
    val completeAchieved: StateFlow<Boolean> = _completeAchieved


    fun loginUser(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _errorMessage.value = null
            val result = userRepository.loginUser(email, password)
            if (result.isSuccess) {
                val user = result.getOrNull()!!
                userPreferences.saveCurrentUser(user.id, user.email, user.fullName)

                _currentEmail.value = user.email

                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "Login failed"
            }
        }
    }

    fun registerUser(fullName: String, email: String, password: String, confirmPassword: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _errorMessage.value = null
            val result = userRepository.registerUser(fullName, email, password, confirmPassword)
            if (result.isSuccess) {
                val user = result.getOrNull()!!
                userPreferences.saveCurrentUser(user.id, user.email, user.fullName)
                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "Registration failed"
            }
        }
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun changePassword(
        email: String,
        change: ChangePassword,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = userRepository.changePassword(email, change.currentPassword, change)
            if (result.isSuccess) {
                onSuccess()
            } else {
                val error = result.exceptionOrNull()?.message ?: "Password change failed"
                onError(error)
            }
        }
    }

    fun setAchievement(email: String, hasLocation: Boolean, isComplete: Boolean){
        viewModelScope.launch{
            if (hasLocation) {

                userRepository.updateLocationAchievement(email, true)
            }
            if (isComplete) {
                userRepository.updateCompleteAchievement(email, true)
            }
            Log.d("Add","Updating Logs")
            userRepository.updateFirstUploadAchievement(email,true)

        }
    }

    fun setEmail(email:String){
        _currentEmail.value = email
    }

    fun loadUserAchievements(email: String) {
        viewModelScope.launch {
            try {
                _firstUploadAchieved.value = userRepository.isFirstUploadAchieved(email)
                _locationAchieved.value = userRepository.isLocationAchieved(email)
                _completeAchieved.value = userRepository.isCompleteAchieved(email)
            } catch (e: Exception) {
                _errorMessage.value = "Failed to load achievements: ${e.message}"
            }
        }
    }


}