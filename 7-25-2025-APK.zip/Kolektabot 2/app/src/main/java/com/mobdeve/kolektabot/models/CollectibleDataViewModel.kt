package com.mobdeve.kolektabot.models

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mobdeve.kolektabot.data.CollectibleRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CollectibleDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val collectibleRepository: CollectibleRepository,
    private val collectibleDao: CollectibleDao
) : ViewModel() {

    private val collectibleId: Int = checkNotNull(savedStateHandle["collectibleId"])

    val collectible: StateFlow<Collectible> =
        collectibleRepository.getCollectibleById(collectibleId)
            .filterNotNull()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = Collectible(
                    id = 0,
                    name = "Loading...",
                    category = "",
                    dateAdded = "",
                    purchasePrice = 0.0,
                    purchaseLocation = "",
                    worthThePrice = false,
                    notes = "",
                    imageUri = null,
                    email = ""
                )
            )

    // 🗑 Delete the current collectible
    fun deleteCollectible() {
        viewModelScope.launch {
            collectibleDao.deleteCollectible(collectible.value)
        }
    }
}
