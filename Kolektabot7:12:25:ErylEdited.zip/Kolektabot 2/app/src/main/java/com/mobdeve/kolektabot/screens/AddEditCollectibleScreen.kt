package com.mobdeve.kolektabot.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.AsyncImage
import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import com.mobdeve.kolektabot.R
import com.mobdeve.kolektabot.models.Collectible
import com.mobdeve.kolektabot.ui.theme.KolektabotTheme
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.layout.ContentScale
import androidx.lifecycle.viewmodel.compose.viewModel
import android.content.Intent
import android.util.Log
import androidx.compose.ui.platform.LocalContext
import com.mobdeve.kolektabot.models.CollectibleViewModel
import com.mobdeve.kolektabot.models.LocationSearchViewModel
import com.mobdeve.kolektabot.viewmodels.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditCollectibleScreen(
    collectible: Collectible? = null,
    onSave: () -> Unit, // Changed the lambda to have no parameters
    onCancel: () -> Unit,
    collectibleViewModel: CollectibleViewModel = hiltViewModel(),
    authViewModel: AuthViewModel,
) {
    // Form state
    var name by remember { mutableStateOf(collectible?.name ?: "") }
    var category by remember { mutableStateOf(collectible?.category ?: "") }
    var purchasePrice by remember { mutableStateOf(collectible?.purchasePrice?.toString() ?: "") }
    var purchaseLocation by remember { mutableStateOf(collectible?.purchaseLocation ?: "") }
    var worthThePrice by remember { mutableStateOf(collectible?.worthThePrice ?: true) }
    var notes by remember { mutableStateOf(collectible?.notes ?: "") }
    var imageUri by remember { mutableStateOf(collectible?.imageUri) }

    // Categories for dropdown
    val categories = listOf("Comics", "Toys", "Trading Cards", "Figurines", "Books", "Other")
    var expanded by remember { mutableStateOf(false) }

    var isDialogOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    val locationSearchViewModel: LocationSearchViewModel = viewModel()
    val searchResults = locationSearchViewModel.searchResults
    val isLoading = locationSearchViewModel.isLoading

    val context = LocalContext.current
    // This acts as an ID.
    val email by authViewModel.currentEmail.collectAsState()
    Log.d("PROFILE","$email")

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        // 2. Add a null check and take persistent permission
        uri?.let {
            try {
                // This is the crucial line that makes the permission permanent
                context.contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                imageUri = it.toString()
            } catch (e: SecurityException) {
                // Handle the case where permission is denied
                e.printStackTrace()
            }
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (collectible == null) "Add Collectible" else "Edit Collectible") },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Cancel")
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = {
                    val newCollectible = Collectible(
                        id = collectible?.id ?: 0, // This is correct, 0 for new items
                        name = name,
                        category = category,
                        dateAdded = if (collectible == null) "Added today" else collectible.dateAdded,
                        purchasePrice = purchasePrice.toDoubleOrNull() ?: 0.0,
                        purchaseLocation = purchaseLocation,
                        worthThePrice = worthThePrice,
                        notes = notes,
                        imageUri = imageUri,
                        email = email.toString()
                    )
                    // Call the ViewModel to save the data
                    collectibleViewModel.addOrUpdateCollectible(newCollectible)
                    // Call the onSave lambda to trigger navigation
                    onSave()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                enabled = name.isNotBlank() && category.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Save Collectible", style = MaterialTheme.typography.labelLarge)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .fillMaxSize()
                .padding(horizontal = 24.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Name Field
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Item Name*") },
                leadingIcon = { Icon(Icons.Default.Info, contentDescription = "Name") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Category Dropdown
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    value = category,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Category*") },
                    leadingIcon = { Icon(Icons.Default.Category, contentDescription = "Category") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )

                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    categories.forEach { selectionOption ->
                        DropdownMenuItem(
                            text = { Text(selectionOption) },
                            onClick = {
                                category = selectionOption
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Purchase Price
            OutlinedTextField(
                value = purchasePrice,
                onValueChange = {
                    if (it.matches(Regex("^\\d*\\.?\\d*$"))) {
                        purchasePrice = it
                    }
                },
                label = { Text("Purchase Price") },
                leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = "Price") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                prefix = { Text("$") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Purchase Location
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = purchaseLocation,
                    onValueChange = {}, // Prevent direct editing
                    label = { Text("Purchase Location") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = "Location") },
                    modifier = Modifier.fillMaxWidth(),
                    readOnly = true // prevent keyboard from showing
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .clickable {
                            isDialogOpen = true
                        }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Worth the Price Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.ThumbUp,
                    contentDescription = "Worth it",
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text("Worth the price?")
                Spacer(modifier = Modifier.width(16.dp))
                Switch(
                    checked = worthThePrice,
                    onCheckedChange = { worthThePrice = it }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Notes Field
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes") },
                leadingIcon = { Icon(Icons.Default.Notes, contentDescription = "Notes") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                maxLines = 5
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Image Picker (Placeholder)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                    .clickable { imagePickerLauncher.launch("image/*") }, // Launch the picker on click
                contentAlignment = Alignment.Center
            ) {
                if (imageUri == null) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Add photo", modifier = Modifier.size(48.dp))
                        Text("Add Photo", style = MaterialTheme.typography.bodyLarge)
                    }
                } else {
                    AsyncImage(
                        model = imageUri,
                        contentDescription = "Selected collectible image",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            }

            if (isDialogOpen) {
                var selectedGeoPoint by remember { mutableStateOf(GeoPoint(14.5995, 120.9842)) }
                Dialog(onDismissRequest = { isDialogOpen = false }) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        tonalElevation = 8.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "Search Location", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))

                            // Location search field
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = {
                                    searchQuery = it
                                    locationSearchViewModel.onQueryChanged(it)
                                },
                                label = { Text("Type a place") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(Modifier.height(8.dp))

                            if (isLoading) {
                                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator()
                                }
                            } else {
                                LazyColumn(modifier = Modifier.heightIn(max = 200.dp)) {
                                    items(searchResults) { place ->
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    purchaseLocation = place.display_name
                                                    searchQuery = place.display_name
                                                    selectedGeoPoint = GeoPoint(place.lat.toDouble(), place.lon.toDouble())
                                                }
                                                .padding(8.dp)
                                        ) {
                                            Text(text = place.display_name)
                                        }
                                    }
                                }
                            }

                            Spacer(Modifier.height(16.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(250.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {

                                AndroidView(
                                    factory = { context ->
                                        Configuration.getInstance().userAgentValue = context.packageName
                                        MapView(context).apply {
                                            setTileSource(TileSourceFactory.MAPNIK)
                                            setUseDataConnection(true)
                                            setMultiTouchControls(false)
                                            isClickable = false
                                            setBuiltInZoomControls(false)
                                            overlays.clear()
                                            controller.setZoom(18.0)
                                            controller.setCenter(selectedGeoPoint) // By default set geopoint to manila
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(250.dp)
                                        .padding(0.dp) // Optional: ensure padding isn't expanding size
                                        .wrapContentHeight(unbounded = false),
                                    update = { mapView ->
                                        mapView.layoutParams.height = 250
                                        mapView.layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT
                                        mapView.controller.animateTo(selectedGeoPoint)
                                    }
                                )
                            }

                            Spacer(Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    purchaseLocation = searchQuery
                                    isDialogOpen = false
                                },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("Select")
                            }
                        }
                    }
                }
            }
        }
    }
}


/*

@Preview(showBackground = true)
@Composable
fun AddEditCollectibleScreenPreview() {
    KolektabotTheme {
        AddEditCollectibleScreen(
            collectible = null,
            onSave = {},
            onCancel = {}
        )
    }
}*/

