package com.mobdeve.kolektabot.di

import android.content.Context
import com.mobdeve.kolektabot.data.KolektabotDatabase
import com.mobdeve.kolektabot.models.CollectibleDao
import com.mobdeve.kolektabot.models.UserDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): KolektabotDatabase {
        return KolektabotDatabase.getDatabase(context)
    }

    @Provides
    fun provideUserDao(database: KolektabotDatabase): UserDao {
        return database.userDao()
    }

    // Add this new provider for CollectibleDao
    @Provides
    fun provideCollectibleDao(database: KolektabotDatabase): CollectibleDao {
        return database.collectibleDao()
    }
}