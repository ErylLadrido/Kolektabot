package com.mobdeve.kolektabot.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.mobdeve.kolektabot.R
import com.mobdeve.kolektabot.models.Collectible
import com.mobdeve.kolektabot.ui.theme.KolektabotTheme
import java.text.NumberFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditCollectibleScreen(
    collectible: Collectible? = null,
    onSave: (Collectible) -> Unit,
    onCancel: () -> Unit
) {
    // Form state
    var name by remember { mutableStateOf(collectible?.name ?: "") }
    var category by remember { mutableStateOf(collectible?.category ?: "") }
    var purchasePrice by remember { mutableStateOf(collectible?.purchasePrice?.toString() ?: "") }
    var purchaseLocation by remember { mutableStateOf(collectible?.purchaseLocation ?: "") }
    var worthThePrice by remember { mutableStateOf(collectible?.worthThePrice ?: true) }
    var notes by remember { mutableStateOf(collectible?.notes ?: "") }

    // Categories for dropdown
    val categories = listOf("Comics", "Toys", "Trading Cards", "Figurines", "Books", "Other")
    var expanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (collectible == null) "Add Collectible" else "Edit Collectible") },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Cancel")
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = {
                    val newCollectible = Collectible(
                        id = collectible?.id ?: 0,
                        name = name,
                        category = category,
                        dateAdded = if (collectible == null) "Added today" else collectible.dateAdded,
                        purchasePrice = purchasePrice.toDoubleOrNull() ?: 0.0,
                        purchaseLocation = purchaseLocation,
                        worthThePrice = worthThePrice,
                        notes = notes,
                        imageRes = R.drawable.placeholder_collectible
                    )
                    onSave(newCollectible)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                enabled = name.isNotBlank() && category.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Save Collectible", style = MaterialTheme.typography.labelLarge)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .fillMaxSize()
                .padding(horizontal = 24.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Name Field
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Item Name*") },
                leadingIcon = { Icon(Icons.Default.Info, contentDescription = "Name") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Category Dropdown
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    value = category,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Category*") },
                    leadingIcon = { Icon(Icons.Default.Category, contentDescription = "Category") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )

                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    categories.forEach { selectionOption ->
                        DropdownMenuItem(
                            text = { Text(selectionOption) },
                            onClick = {
                                category = selectionOption
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Purchase Price
            OutlinedTextField(
                value = purchasePrice,
                onValueChange = {
                    if (it.matches(Regex("^\\d*\\.?\\d*$"))) {
                        purchasePrice = it
                    }
                },
                label = { Text("Purchase Price") },
                leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = "Price") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                prefix = { Text("$") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Purchase Location
            OutlinedTextField(
                value = purchaseLocation,
                onValueChange = { purchaseLocation = it },
                label = { Text("Purchase Location") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = "Location") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Worth the Price Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.ThumbUp,
                    contentDescription = "Worth it",
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text("Worth the price?")
                Spacer(modifier = Modifier.width(16.dp))
                Switch(
                    checked = worthThePrice,
                    onCheckedChange = { worthThePrice = it }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Notes Field
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes") },
                leadingIcon = { Icon(Icons.Default.Notes, contentDescription = "Notes") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                maxLines = 5
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Image Picker (Placeholder)
            Button(
                onClick = { /* Handle image selection */ },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            ) {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Add photo")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add Photo")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AddEditCollectibleScreenPreview() {
    KolektabotTheme {
        AddEditCollectibleScreen(
            collectible = null,
            onSave = {},
            onCancel = {}
        )
    }
}
