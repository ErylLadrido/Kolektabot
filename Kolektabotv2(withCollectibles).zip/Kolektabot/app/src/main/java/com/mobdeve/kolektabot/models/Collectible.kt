package com.mobdeve.kolektabot.models

data class Collectible(
    val id: Int,
    val name: String,
    val category: String,
    val dateAdded: String,
    val purchasePrice: Double,
    val purchaseLocation: String,
    val worthThePrice: Boolean,
    val notes: String?,
    val imageRes: Int
)