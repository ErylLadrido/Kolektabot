package com.mobdeve.kolektabot.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.mobdeve.kolektabot.R
import com.mobdeve.kolektabot.models.Collectible
import com.mobdeve.kolektabot.ui.theme.KolektabotTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectiblesListScreen(
    collectibles: List<Collectible>,
    onCollectibleClick: (Collectible) -> Unit,
    onNavigateBack: () -> Unit,
    onAddCollectible: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Collection") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Handle search */ }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddCollectible,
                icon = { Icon(Icons.Default.Add, contentDescription = "Add") },
                text = { Text("Add Item") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search collection...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )

            // Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = true,
                    onClick = { /* Toggle filter */ },
                    label = { Text("All") }
                )
                FilterChip(
                    selected = false,
                    onClick = { /* Toggle filter */ },
                    label = { Text("Comics") }
                )
                FilterChip(
                    selected = false,
                    onClick = { /* Toggle filter */ },
                    label = { Text("Toys") }
                )
            }

            // Collectibles List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(collectibles) { collectible ->
                    CollectibleItem(
                        collectible = collectible,
                        onClick = { onCollectibleClick(collectible) }
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun CollectiblesListScreenPreview() {
    val sampleCollectibles = listOf(
        Collectible(
            id = 1,
            name = "Rare Comic #1",
            category = "Comics",
            dateAdded = "Added today",
            purchasePrice = 49.99,
            purchaseLocation = "Comic Con",
            worthThePrice = true,
            notes = "Mint condition, first edition",
            imageRes = R.drawable.placeholder_collectible
        ),
        Collectible(
            id = 2,
            name = "Vintage Toy",
            category = "Toys",
            dateAdded = "Added 2 days ago",
            purchasePrice = 120.0,
            purchaseLocation = "Antique Shop",
            worthThePrice = true,
            notes = "Original packaging",
            imageRes = R.drawable.placeholder_collectible
        )
    )

    KolektabotTheme {
        CollectiblesListScreen(
            collectibles = sampleCollectibles,
            onCollectibleClick = {},
            onNavigateBack = {},
            onAddCollectible = {}
        )
    }
}