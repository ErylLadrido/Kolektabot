package com.mobdeve.kolektabot.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "collectibles")
data class Collectible(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val category: String,
    val dateAdded: String,
    val purchasePrice: Double,
    val purchaseLocation: String,
    val worthThePrice: Boolean,
    val notes: String?,
    // CHANGE THIS: from Int to a nullable String
    val imageUri: String?,
    val isWishlistItem: Boolean = false
)