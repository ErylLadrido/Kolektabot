package com.mobdeve.kolektabot.models

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mobdeve.kolektabot.data.CollectibleRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class AddEditViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    collectibleRepository: CollectibleRepository
) : ViewModel() {

    // Get the collectibleId from navigation arguments. It can be null if we are adding.
    private val collectibleId: Int? = savedStateHandle.get<Int>("collectibleId")

    // This will hold the collectible we are editing.
    // It will be null if we are adding a new one.
    val collectible: StateFlow<Collectible?> =
        // Only fetch from the database if we were given an ID
        if (collectibleId != null) {
            collectibleRepository.getCollectibleById(collectibleId)
        } else {
            // Otherwise, provide an empty flow for the "add" case
            kotlinx.coroutines.flow.flowOf(null)
        }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = null
            )
}