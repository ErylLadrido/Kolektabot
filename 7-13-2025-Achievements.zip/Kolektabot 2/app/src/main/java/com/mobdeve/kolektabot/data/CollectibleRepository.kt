package com.mobdeve.kolektabot.data

import com.mobdeve.kolektabot.models.Collectible
import com.mobdeve.kolektabot.models.CollectibleDao
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class CollectibleRepository @Inject constructor(private val collectibleDao: CollectibleDao) {

    fun getAllCollectibles(email : String): Flow<List<Collectible>> {
        return collectibleDao.getAllCollectibles(email)
    }

    fun getCollectibleById(id: Int): Flow<Collectible> {
        return collectibleDao.getCollectibleById(id)
    }

    suspend fun insertOrUpdate(collectible: Collectible) {
        collectibleDao.insertOrUpdateCollectible(collectible)
    }

    suspend fun delete(collectible: Collectible) {
        collectibleDao.deleteCollectible(collectible)
    }
}