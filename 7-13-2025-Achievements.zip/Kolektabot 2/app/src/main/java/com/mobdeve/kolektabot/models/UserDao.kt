package com.mobdeve.kolektabot.models

import androidx.room.*
import com.mobdeve.kolektabot.models.User

@Dao
interface UserDao {
    @Insert
    suspend fun insertUser(user: User): Long

    @Query("SELECT * FROM users WHERE email = :email AND password = :password LIMIT 1")
    suspend fun loginUser(email: String, password: String): User?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): User?

    @Query("SELECT * FROM users WHERE id = :userId")
    suspend fun getUserById(userId: Int): User?

    @Update
    suspend fun updateUser(user: User)

    @Query("UPDATE users SET password = :newPassword WHERE email = :email")
    suspend fun updatePassword(email: String, newPassword: String)

    @Query("UPDATE users SET completeAchievement = :status WHERE email = :email")
    suspend fun updateComplete(email: String, status: Boolean)

    @Query("UPDATE users SET locationAchievement = :status WHERE email = :email")
    suspend fun updateLocation(email: String, status: Boolean)

    @Query("UPDATE users SET firstUpAchievement = :status WHERE email = :email")
    suspend fun updateFirst(email: String, status: Boolean)

    @Delete
    suspend fun deleteUser(user: User)

    @Query("SELECT firstUpAchievement FROM users WHERE email = :email")
    suspend fun isFirstUploadAchieved(email: String): Boolean

    @Query("SELECT locationAchievement FROM users WHERE email = :email")
    suspend fun isLocationAchieved(email: String): Boolean

    @Query("SELECT completeAchievement FROM users WHERE email = :email")
    suspend fun isCompleteAchieved(email: String): Boolean
}