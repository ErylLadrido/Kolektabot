package com.mobdeve.kolektabot.models

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import android.util.Log
import com.mobdeve.kolektabot.api.NominatimPlace
import com.mobdeve.kolektabot.api.RetrofitInstance
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Job

class LocationSearchViewModel : ViewModel() {

    var searchResults by mutableStateOf<List<NominatimPlace>>(emptyList())
        private set

    var isLoading by mutableStateOf(false)
        private set

    private val _query = MutableStateFlow("")
    private var searchJob: Job? = null

    init {
        observeQuery()
    }

    fun onQueryChanged(newQuery: String) {
        _query.value = newQuery
    }

    private fun observeQuery() {
        viewModelScope.launch {
            _query
                .debounce(500) // wait for 500ms of inactivity
                .distinctUntilChanged()
                .filter { it.length >= 3 } // only search if 3+ characters
                .collect { query ->
                    performSearch(query)
                }
        }
    }

    private suspend fun performSearch(query: String) {
        isLoading = true
        try {
            searchResults = RetrofitInstance.api.search(query)
            Log.d("LocationSearchViewModel", "Search results: $searchResults")
        } catch (e: Exception) {
            searchResults = emptyList()
            Log.e("LocationSearchViewModel", "Search error", e)
        } finally {
            isLoading = false
        }
    }
}
