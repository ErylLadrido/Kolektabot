// KolektabotApplication.kt
package com.mobdeve.kolektabot

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class KolektabotApplication : Application()