package com.mobdeve.kolektabot.navigation


import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.mobdeve.kolektabot.screens.LoginScreen
import com.mobdeve.kolektabot.screens.RegisterScreen
import com.mobdeve.kolektabot.screens.HomeScreen
import com.mobdeve.kolektabot.screens.SplashScreen
import com.mobdeve.kolektabot.screens.CollectiblesListScreen
import com.mobdeve.kolektabot.screens.CollectibleDetailScreen
import com.mobdeve.kolektabot.screens.AddEditCollectibleScreen
import com.mobdeve.kolektabot.screens.WishlistScreen
import com.mobdeve.kolektabot.models.Collectible
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.mobdeve.kolektabot.R
import com.mobdeve.kolektabot.screens.ProfileScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "splash"
    ) {
        composable("splash") {
            SplashScreen(
                onNavigateToLogin = {
                    navController.navigate("login") {
                        popUpTo("splash") { inclusive = true }
                    }
                }
            )
        }
        composable("login") {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate("register") {
                        // This ensures smooth transition to register screen
                        launchSingleTop = true
                    }
                }
            )
        }
        composable("register") {
            RegisterScreen(
                onRegisterSuccess = {
                    navController.navigate("home") {
                        popUpTo("register") { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    navController.navigate("login") {
                        launchSingleTop = true
                        popUpTo("register") { inclusive = true }
                    }
                }
            )
        }
        composable("home") {
            HomeScreen(
                onNavigateToCollection = { navController.navigate("collection") },
                onNavigateToWishlist = { navController.navigate("wishlist")},
                onNavigateToAddItem = { navController.navigate("addCollectible") },
                onNavigateToProfile = {navController.navigate("profile")}
            )
        }

        composable("collection") {
            // In a real app, you would fetch collectibles from a repository
            val sampleCollectibles = listOf(
                Collectible(
                    id = 1,
                    name = "Rare Comic #1",
                    category = "Comics",
                    dateAdded = "Added today",
                    purchasePrice = 49.99,
                    purchaseLocation = "Comic Con",
                    worthThePrice = true,
                    notes = "Mint condition, first edition",
                    imageRes = R.drawable.placeholder_collectible
                ),
                // ... more sample items ...
            )

            CollectiblesListScreen(
                collectibles = sampleCollectibles,
                onCollectibleClick = { collectible ->
                    navController.navigate("detail/${collectible.id}")
                },
                onNavigateBack = { navController.popBackStack() },
                onAddCollectible = { navController.navigate("addCollectible") }
            )
        }

        composable(
            route = "detail/{collectibleId}",
            arguments = listOf(
                navArgument("collectibleId") {
                    type = NavType.IntType
                }
            )
        ) { backStackEntry ->
            val collectibleId = backStackEntry.arguments?.getInt("collectibleId") ?: 0
            // In a real app, fetch collectible by ID from repository
            val collectible = Collectible(
                id = collectibleId,
                name = "Sample Item",
                category = "Sample Category",
                dateAdded = "Added today",
                purchasePrice = 0.0,
                purchaseLocation = "Sample Location",
                worthThePrice = true,
                notes = "Sample notes",
                imageRes = R.drawable.placeholder_collectible
            )

            CollectibleDetailScreen(
                collectible = collectible,
                onEditCollectible = {
                    navController.navigate("edit/${collectible.id}")
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable("addCollectible") {
            AddEditCollectibleScreen(
                collectible = null,
                onSave = { newCollectible ->
                    // Save logic would go here
                    navController.popBackStack("collection", inclusive = false)
                },
                onCancel = { navController.popBackStack() }
            )
        }

        composable(
            route = "edit/{collectibleId}",
            arguments = listOf(
                navArgument("collectibleId") {
                    type = NavType.IntType
                }
            )
        ) { backStackEntry ->
            val collectibleId = backStackEntry.arguments?.getInt("collectibleId") ?: 0
            // In a real app, fetch collectible by ID from repository
            val collectible = Collectible(
                id = collectibleId,
                name = "Sample Item",
                category = "Sample Category",
                dateAdded = "Added today",
                purchasePrice = 0.0,
                purchaseLocation = "Sample Location",
                worthThePrice = true,
                notes = "Sample notes",
                imageRes = R.drawable.placeholder_collectible
            )

            AddEditCollectibleScreen(
                collectible = collectible,
                onSave = { updatedCollectible ->
                    // Update logic would go here
                    navController.popBackStack()
                },
                onCancel = { navController.popBackStack() }
            )
        }
        composable("wishlist"){
            WishlistScreen(
                onNavigateToCollection = { navController.navigate("collection") },
                onNavigateToWishlist = { navController.navigate("wishlist")},
                onNavigateToHome= { navController.navigate("home") },
                onNavigateToProfile = {navController.navigate("profile")}
            )
        }
        composable("profile"){
            ProfileScreen(
                onNavigateToCollection = { navController.navigate("collection") },
                onNavigateToWishlist = { navController.navigate("wishlist")},
                onNavigateToHome= { navController.navigate("home") }
            )
        }

    }
}