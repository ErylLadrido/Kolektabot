package com.mobdeve.kolektabot.screens
import retrofit2.http.GET
import retrofit2.http.Query

interface NominatimApi {
    @GET("search")
    suspend fun search(
        @Query("q") query: String,
        @Query("format") format: String = "json",
        @Query("limit") limit: Int = 5,
        @Query("countrycodes") countryCodes: String = "ph",
        @Query("addressdetails") addressDetails: Int = 1
    ): List<NominatimPlace>
}

data class NominatimPlace(
    val display_name: String,
    val lat: String,
    val lon: String
)
